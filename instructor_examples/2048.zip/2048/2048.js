var boardDiv = document.querySelector("#board");

for (var i = 0; i < 4; i++) {
  var rowDiv = document.createElement("div");
  rowDiv.classList.add("row");
  boardDiv.appendChild(rowDiv);

  for (var j = 0; j < 4; j++) {
    var tileDiv = document.createElement("div");
    tileDiv.classList.add("tile");
    rowDiv.appendChild(tileDiv);
  }
}


