import React from 'react';

export default () => (
  <div className="page-not-found">
    <h4>Page not found</h4>
  </div>
);
